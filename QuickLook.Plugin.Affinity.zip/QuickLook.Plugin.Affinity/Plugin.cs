﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using QuickLook.Common.Plugin;

namespace QuickLook.Plugin.AffinityViewer
{
    public class Plugin : IViewer
    {
        private sealed class PngCandidate
        {
            public long StartPos { get; set; }
            public int Length { get; set; }
            public int Width { get; set; }
            public int Height { get; set; }
            public long Area => (long)Width * Height;
        }

        private static readonly HashSet<string> SupportedExtensions = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            ".afphoto",
            ".afdesign",
            ".afpub",
            ".af"
        };

        private static readonly byte[] PngSignature = { 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A };
        private static readonly byte[] PngIendTrailer = { 0x49, 0x45, 0x4E, 0x44, 0xAE, 0x42, 0x60, 0x82 };

        private const int SignatureScanChunkSize = 1024 * 1024;
        private const int MaxPngScanBytes = 50 * 1024 * 1024;

        public int Priority => 0;

        public void Init()
        {
        }

        public bool CanHandle(string path)
        {
            if (string.IsNullOrWhiteSpace(path) || Directory.Exists(path))
            {
                return false;
            }

            var ext = Path.GetExtension(path);
            return !string.IsNullOrEmpty(ext) && SupportedExtensions.Contains(ext);
        }

        public void Prepare(string path, ContextObject context)
        {
            context.PreferredSize = new Size { Width = 900, Height = 650 };
            context.Theme = Themes.Dark;
        }

        public void View(string path, ContextObject context)
        {
            context.IsBusy = true;

            var grid = new Grid
            {
                Background = Brushes.Transparent
            };

            DrawingBrush CreateCheckerboard(Themes theme)
            {
                var a = theme == Themes.Dark ? Color.FromRgb(26, 26, 26) : Color.FromRgb(245, 245, 245);
                var b = theme == Themes.Dark ? Color.FromRgb(34, 34, 34) : Color.FromRgb(255, 255, 255);

                var drawing = new DrawingGroup();
                drawing.Children.Add(new GeometryDrawing(new SolidColorBrush(a), null, new RectangleGeometry(new Rect(0, 0, 32, 32))));
                drawing.Children.Add(new GeometryDrawing(new SolidColorBrush(b), null, new RectangleGeometry(new Rect(0, 0, 16, 16))));
                drawing.Children.Add(new GeometryDrawing(new SolidColorBrush(b), null, new RectangleGeometry(new Rect(16, 16, 16, 16))));
                drawing.Freeze();

                var brush = new DrawingBrush(drawing)
                {
                    TileMode = TileMode.Tile,
                    Viewport = new Rect(0, 0, 32, 32),
                    ViewportUnits = BrushMappingMode.Absolute,
                    Stretch = Stretch.Fill
                };
                brush.Freeze();
                return brush;
            }

            var background = new System.Windows.Shapes.Rectangle
            {
                Fill = CreateCheckerboard(context.Theme)
            };

            var scroll = new ScrollViewer
            {
                BorderThickness = new Thickness(0),
                Focusable = false,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Auto,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                PanningMode = PanningMode.Both
            };

            var image = new Image
            {
                Stretch = Stretch.None,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center
            };

            RenderOptions.SetBitmapScalingMode(image, BitmapScalingMode.HighQuality);

            var zoomTransform = new ScaleTransform(1d, 1d);
            image.LayoutTransform = zoomTransform;

            var host = new Grid
            {
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center
            };
            host.Children.Add(image);
            scroll.Content = host;

            var zoomInfoText = new TextBlock
            {
                FontSize = 18,
                Foreground = Brushes.White,
                Text = "100%"
            };

            var zoomInfo = new Border
            {
                Padding = new Thickness(15, 4, 15, 4),
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                Background = Brushes.Gray,
                CornerRadius = new CornerRadius(5),
                IsHitTestVisible = false,
                Opacity = 0,
                Child = zoomInfoText
            };

            void ShowZoomInfo(double factor)
            {
                zoomInfoText.Text = $"{factor * 100:0}%";

                var sb = new Storyboard();
                var anim = new DoubleAnimationUsingKeyFrames();
                anim.KeyFrames.Add(new LinearDoubleKeyFrame(0.9, KeyTime.FromTimeSpan(TimeSpan.FromSeconds(0.1))));
                anim.KeyFrames.Add(new LinearDoubleKeyFrame(0.9, KeyTime.FromTimeSpan(TimeSpan.FromSeconds(0.6))));
                anim.KeyFrames.Add(new LinearDoubleKeyFrame(0, KeyTime.FromTimeSpan(TimeSpan.FromSeconds(0.8))));
                Storyboard.SetTarget(anim, zoomInfo);
                Storyboard.SetTargetProperty(anim, new PropertyPath(UIElement.OpacityProperty));
                sb.Children.Add(anim);
                sb.Begin();
            }

            Style CreateTopRightButtonStyle(Themes theme)
            {
                var fg = theme == Themes.Dark
                    ? new SolidColorBrush(Color.FromArgb(0xE5, 0xEF, 0xEF, 0xEF))
                    : new SolidColorBrush(Color.FromArgb(0xE5, 0x0E, 0x0E, 0x0E));

                var hover = theme == Themes.Dark
                    ? new SolidColorBrush(Color.FromArgb(0x22, 0xFF, 0xFF, 0xFF))
                    : new SolidColorBrush(Color.FromArgb(0x44, 0xFF, 0xFF, 0xFF));

                var press = theme == Themes.Dark
                    ? new SolidColorBrush(Color.FromArgb(0x44, 0xFF, 0xFF, 0xFF))
                    : new SolidColorBrush(Color.FromArgb(0x88, 0xFF, 0xFF, 0xFF));

                fg.Freeze();
                hover.Freeze();
                press.Freeze();

                var template = new ControlTemplate(typeof(Button));
                var border = new FrameworkElementFactory(typeof(Border));
                border.SetValue(Border.BackgroundProperty, new TemplateBindingExtension(Control.BackgroundProperty));
                var presenter = new FrameworkElementFactory(typeof(ContentPresenter));
                presenter.SetValue(ContentPresenter.HorizontalAlignmentProperty, HorizontalAlignment.Center);
                presenter.SetValue(ContentPresenter.VerticalAlignmentProperty, VerticalAlignment.Center);
                border.AppendChild(presenter);
                template.VisualTree = border;

                var style = new Style(typeof(Button));
                style.Setters.Add(new Setter(FrameworkElement.WidthProperty, 24d));
                style.Setters.Add(new Setter(FrameworkElement.HeightProperty, 24d));
                style.Setters.Add(new Setter(Control.FontSizeProperty, 12d));
                style.Setters.Add(new Setter(Control.ForegroundProperty, fg));
                style.Setters.Add(new Setter(Control.BackgroundProperty, Brushes.Transparent));
                style.Setters.Add(new Setter(Control.BorderThicknessProperty, new Thickness(0)));
                style.Setters.Add(new Setter(Control.PaddingProperty, new Thickness(0)));
                style.Setters.Add(new Setter(UIElement.FocusableProperty, false));
                style.Setters.Add(new Setter(FrameworkElement.CursorProperty, Cursors.Hand));
                style.Setters.Add(new Setter(Control.TemplateProperty, template));

                style.Triggers.Add(new Trigger
                {
                    Property = UIElement.IsMouseOverProperty,
                    Value = true,
                    Setters = { new Setter(Control.BackgroundProperty, hover) }
                });
                style.Triggers.Add(new Trigger
                {
                    Property = ButtonBase.IsPressedProperty,
                    Value = true,
                    Setters = { new Setter(Control.BackgroundProperty, press) }
                });

                return style;
            }

            var themeButton = new Button
            {
                Margin = new Thickness(0, 8, 8, 0),
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment = VerticalAlignment.Top,
                Content = "暗",
            };

            var loadBigButton = new Button
            {
                Margin = new Thickness(0, 8, 8, 0),
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment = VerticalAlignment.Top,
                Content = "大",
                Visibility = Visibility.Collapsed
            };

            void ApplyTheme(Themes theme)
            {
                context.Theme = theme;
                background.Fill = CreateCheckerboard(theme);
                themeButton.Content = theme == Themes.Dark ? "暗" : "亮";
                themeButton.Style = CreateTopRightButtonStyle(theme);
                loadBigButton.Style = CreateTopRightButtonStyle(theme);
            }

            var status = new TextBlock
            {
                Visibility = Visibility.Collapsed,
                TextWrapping = TextWrapping.Wrap,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                Foreground = Brushes.Gainsboro,
                Margin = new Thickness(24),
                MaxWidth = 700
            };

            themeButton.Click += (_, __) =>
            {
                ApplyTheme(context.Theme == Themes.Dark ? Themes.Light : Themes.Dark);
            };

            ApplyTheme(context.Theme);

            grid.Children.Add(background);
            grid.Children.Add(scroll);
            grid.Children.Add(zoomInfo);
            var topButtons = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment = VerticalAlignment.Top
            };
            topButtons.Children.Add(loadBigButton);
            topButtons.Children.Add(themeButton);
            grid.Children.Add(topButtons);
            grid.Children.Add(status);

            context.ViewerContent = grid;
            context.Title = $"{Path.GetFileName(path)}";

            BitmapImage bmp = null;
            PngCandidate thumbCandidate = null;
            PngCandidate maxCandidate = null;
            var isShowingMax = false;
            var zoomFactor = 1d;
            var zoomToFit = true;

            void UpdateTitle()
            {
                if (thumbCandidate == null)
                {
                    context.Title = $"{Path.GetFileName(path)}";
                    return;
                }

                var thumb = $"{thumbCandidate.Width}×{thumbCandidate.Height}";
                if (maxCandidate == null || (maxCandidate.Width == thumbCandidate.Width && maxCandidate.Height == thumbCandidate.Height))
                {
                    context.Title = $"缩略图 {thumb}: {Path.GetFileName(path)}";
                    return;
                }

                var max = $"{maxCandidate.Width}×{maxCandidate.Height}";
                context.Title = $"缩略图 {thumb} | 预览 {max}: {Path.GetFileName(path)}";
            }

            void ApplyZoom(double newZoom)
            {
                if (newZoom < 0.05d) newZoom = 0.05d;
                if (newZoom > 10d) newZoom = 10d;

                if (Math.Abs(newZoom - zoomFactor) < 0.000001d)
                {
                    return;
                }

                var oldZoom = zoomFactor;
                zoomFactor = newZoom;

                var pivot = new Point(scroll.ViewportWidth / 2d, scroll.ViewportHeight / 2d);
                var absX = scroll.HorizontalOffset + pivot.X;
                var absY = scroll.VerticalOffset + pivot.Y;
                var ratio = zoomFactor / oldZoom;
                var newAbsX = absX * ratio;
                var newAbsY = absY * ratio;

                zoomTransform.ScaleX = zoomFactor;
                zoomTransform.ScaleY = zoomFactor;

                scroll.UpdateLayout();

                var newOffsetX = newAbsX - pivot.X;
                var newOffsetY = newAbsY - pivot.Y;

                if (newOffsetX < 0) newOffsetX = 0;
                if (newOffsetY < 0) newOffsetY = 0;

                var maxX = Math.Max(0d, scroll.ExtentWidth - scroll.ViewportWidth);
                var maxY = Math.Max(0d, scroll.ExtentHeight - scroll.ViewportHeight);
                if (newOffsetX > maxX) newOffsetX = maxX;
                if (newOffsetY > maxY) newOffsetY = maxY;

                scroll.ScrollToHorizontalOffset(newOffsetX);
                scroll.ScrollToVerticalOffset(newOffsetY);

                ShowZoomInfo(zoomFactor);
            }

            void DoZoomToFit()
            {
                if (bmp == null)
                {
                    return;
                }

                if (scroll.ViewportWidth <= 1 || scroll.ViewportHeight <= 1)
                {
                    return;
                }

                var fit = Math.Min(scroll.ViewportWidth / bmp.PixelWidth, scroll.ViewportHeight / bmp.PixelHeight);
                if (double.IsNaN(fit) || double.IsInfinity(fit) || fit <= 0)
                {
                    fit = 1d;
                }

                zoomToFit = true;
                ApplyZoom(fit);
                scroll.ScrollToHorizontalOffset(0);
                scroll.ScrollToVerticalOffset(0);
            }

            scroll.SizeChanged += (_, __) =>
            {
                host.MinWidth = scroll.ViewportWidth;
                host.MinHeight = scroll.ViewportHeight;

                if (zoomToFit)
                {
                    DoZoomToFit();
                }
            };

            scroll.PreviewMouseWheel += (_, e) =>
            {
                if (bmp == null)
                {
                    return;
                }

                e.Handled = true;
                zoomToFit = false;

                var delta = e.Delta > 0 ? 1.15d : 1d / 1.15d;
                ApplyZoom(zoomFactor * delta);
            };

            Point? dragStart = null;
            double dragStartX = 0;
            double dragStartY = 0;

            scroll.PreviewMouseLeftButtonDown += (_, e) =>
            {
                if (bmp == null)
                {
                    return;
                }

                dragStart = e.GetPosition(scroll);
                dragStartX = scroll.HorizontalOffset;
                dragStartY = scroll.VerticalOffset;
                scroll.CaptureMouse();
                e.Handled = true;
            };

            scroll.PreviewMouseMove += (_, e) =>
            {
                if (dragStart == null || !scroll.IsMouseCaptured)
                {
                    return;
                }

                var cur = e.GetPosition(scroll);
                var dx = cur.X - dragStart.Value.X;
                var dy = cur.Y - dragStart.Value.Y;
                scroll.ScrollToHorizontalOffset(dragStartX - dx);
                scroll.ScrollToVerticalOffset(dragStartY - dy);
            };

            scroll.PreviewMouseLeftButtonUp += (_, e) =>
            {
                if (scroll.IsMouseCaptured)
                {
                    scroll.ReleaseMouseCapture();
                }

                dragStart = null;
                e.Handled = true;
            };

            scroll.MouseDoubleClick += (_, e) =>
            {
                if (bmp == null)
                {
                    return;
                }

                if (zoomToFit)
                {
                    zoomToFit = false;
                    ApplyZoom(1d);
                }
                else
                {
                    DoZoomToFit();
                }

                e.Handled = true;
            };

            loadBigButton.Click += (_, __) =>
            {
                if (thumbCandidate == null)
                {
                    return;
                }

                isShowingMax = !isShowingMax;
                context.IsBusy = true;
                status.Visibility = Visibility.Collapsed;

                _ = Task.Run(() =>
                {
                    Exception error = null;
                    BitmapImage newBmp = null;

                    try
                    {
                        var candidate = isShowingMax && maxCandidate != null ? maxCandidate : thumbCandidate;
                        var bytes = ReadRange(path, candidate.StartPos, candidate.Length);
                        newBmp = bytes == null ? null : LoadBitmapImage(bytes);
                    }
                    catch (Exception ex)
                    {
                        error = ex;
                    }

                    grid.Dispatcher.Invoke(() =>
                    {
                        try
                        {
                            if (error != null || newBmp == null)
                            {
                                status.Text = error == null ? "加载图像失败。" : $"加载图像失败：{error.Message}";
                                status.Visibility = Visibility.Visible;
                                isShowingMax = false;
                                loadBigButton.Content = "大";
                            }
                            else
                            {
                                bmp = newBmp;
                                image.Source = bmp;
                                loadBigButton.Content = isShowingMax ? "小" : "大";
                                grid.Dispatcher.InvokeAsync(DoZoomToFit, DispatcherPriority.Loaded);
                            }
                        }
                        finally
                        {
                            context.IsBusy = false;
                        }
                    }, DispatcherPriority.Loaded);
                });
            };

            _ = Task.Run(() =>
            {
                PngCandidate thumb = null;
                PngCandidate max = null;
                Exception error = null;

                try
                {
                    FindThumbAndMaxEmbeddedPng(path, out thumb, out max);
                }
                catch (Exception ex)
                {
                    error = ex;
                }

                grid.Dispatcher.Invoke(() =>
                {
                    try
                    {
                        if (thumb == null)
                        {
                            image.Source = null;
                            status.Text = error == null ? "未找到可用的 Affinity 缩略图（PNG）。" : $"提取缩略图失败：{error.Message}";
                            status.Visibility = Visibility.Visible;
                        }
                        else
                        {
                            status.Visibility = Visibility.Collapsed;
                            thumbCandidate = thumb;
                            maxCandidate = max;
                            isShowingMax = false;

                            var bytes = ReadRange(path, thumbCandidate.StartPos, thumbCandidate.Length);
                            bmp = bytes == null ? null : LoadBitmapImage(bytes);
                            image.Source = bmp;

                            loadBigButton.Visibility = maxCandidate != null && maxCandidate.Area > thumbCandidate.Area
                                ? Visibility.Visible
                                : Visibility.Collapsed;
                            loadBigButton.Content = "大";

                            UpdateTitle();
                            grid.Dispatcher.InvokeAsync(DoZoomToFit, DispatcherPriority.Loaded);
                        }
                    }
                    finally
                    {
                        context.IsBusy = false;
                    }
                }, DispatcherPriority.Loaded);
            });
        }

        public void Cleanup()
        {
        }

        private static BitmapImage LoadBitmapImage(byte[] data)
        {
            using (var ms = new MemoryStream(data, writable: false))
            {
                ms.Position = 0;

                var bmp = new BitmapImage();
                bmp.BeginInit();
                bmp.CacheOption = BitmapCacheOption.OnLoad;
                bmp.StreamSource = ms;
                bmp.EndInit();
                bmp.Freeze();
                return bmp;
            }
        }

        private static void FindThumbAndMaxEmbeddedPng(string path, out PngCandidate thumb, out PngCandidate max)
        {
            thumb = null;
            max = null;

            var fileInfo = new FileInfo(path);
            if (!fileInfo.Exists)
            {
                return;
            }

            var tail = new byte[PngSignature.Length - 1];
            var tailLen = 0;

            using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                var buffer = new byte[SignatureScanChunkSize + tail.Length];
                long absoluteOffset = 0;

                while (true)
                {
                    Buffer.BlockCopy(tail, 0, buffer, 0, tailLen);
                    var read = fs.Read(buffer, tailLen, SignatureScanChunkSize);
                    if (read <= 0)
                    {
                        break;
                    }

                    var windowLen = tailLen + read;
                    var searchStart = 0;

                    while (searchStart <= windowLen - PngSignature.Length)
                    {
                        var idx = IndexOfSequence(buffer, searchStart, windowLen, PngSignature);
                        if (idx < 0)
                        {
                            break;
                        }

                        var startPos = absoluteOffset - tailLen + idx;
                        var candidate = TryReadPngCandidateAt(path, startPos);
                        if (candidate != null)
                        {
                            if (thumb == null || candidate.Length < thumb.Length)
                            {
                                thumb = candidate;
                            }

                            if (max == null || candidate.Area > max.Area)
                            {
                                max = candidate;
                            }
                        }

                        searchStart = idx + PngSignature.Length;
                    }

                    tailLen = Math.Min(tail.Length, windowLen);
                    Buffer.BlockCopy(buffer, windowLen - tailLen, tail, 0, tailLen);
                    absoluteOffset += read;
                }
            }
        }

        private static PngCandidate TryReadPngCandidateAt(string path, long startPos)
        {
            if (startPos < 0)
            {
                return null;
            }

            using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                if (startPos >= fs.Length)
                {
                    return null;
                }

                fs.Position = startPos;

                var remaining = fs.Length - startPos;
                var toRead = (int)Math.Min(remaining, MaxPngScanBytes);
                if (toRead < 57)
                {
                    return null;
                }

                var window = new byte[toRead];
                var totalRead = 0;
                while (totalRead < toRead)
                {
                    var r = fs.Read(window, totalRead, toRead - totalRead);
                    if (r <= 0)
                    {
                        break;
                    }

                    totalRead += r;
                }

                if (totalRead < 57)
                {
                    return null;
                }

                var iendIndex = IndexOfSequence(window, 0, totalRead, PngIendTrailer);
                if (iendIndex < 0)
                {
                    return null;
                }

                var pngLen = iendIndex + 12;
                if (pngLen < 57 || pngLen > totalRead)
                {
                    return null;
                }

                if (pngLen < 24 || totalRead < 24)
                {
                    return null;
                }

                if (window[12] != 0x49 || window[13] != 0x48 || window[14] != 0x44 || window[15] != 0x52)
                {
                    return null;
                }

                var w = ReadInt32BigEndian(window, 16);
                var h = ReadInt32BigEndian(window, 20);
                if (w <= 0 || h <= 0)
                {
                    return null;
                }

                return new PngCandidate
                {
                    StartPos = startPos,
                    Length = pngLen,
                    Width = w,
                    Height = h
                };
            }
        }

        private static int ReadInt32BigEndian(byte[] buffer, int offset)
        {
            return (buffer[offset] << 24) | (buffer[offset + 1] << 16) | (buffer[offset + 2] << 8) | buffer[offset + 3];
        }

        private static byte[] ReadRange(string path, long startPos, int length)
        {
            var data = new byte[length];
            using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                fs.Position = startPos;
                var read = 0;
                while (read < length)
                {
                    var r = fs.Read(data, read, length - read);
                    if (r <= 0)
                    {
                        break;
                    }

                    read += r;
                }

                if (read != length)
                {
                    return null;
                }
            }

            return data;
        }

        private static int IndexOfSequence(byte[] buffer, int start, int length, byte[] pattern)
        {
            var limit = length - pattern.Length;
            for (var i = start; i <= limit; i++)
            {
                var matched = true;
                for (var j = 0; j < pattern.Length; j++)
                {
                    if (buffer[i + j] != pattern[j])
                    {
                        matched = false;
                        break;
                    }
                }

                if (matched)
                {
                    return i;
                }
            }

            return -1;
        }
    }
}
