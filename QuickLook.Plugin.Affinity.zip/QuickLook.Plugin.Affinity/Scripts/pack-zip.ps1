$ProgressPreference = "SilentlyContinue"
$root = Split-Path -Parent $PSScriptRoot
$outPlugin = Join-Path $root "QuickLook.Plugin.AffinityViewer.qlplugin"
$outZip = Join-Path $root "QuickLook.Plugin.AffinityViewer.zip"
$releasePath = Join-Path $root "bin\\Release"

Remove-Item $outPlugin -ErrorAction SilentlyContinue

$files = Get-ChildItem -Path $releasePath -Exclude *.pdb,*.xml
Compress-Archive $files $outZip
Move-Item $outZip $outPlugin
